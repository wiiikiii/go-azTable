package manipulateAzTable

var TierSelectValues = []string{"Tier1", "Tier2", "Tier3"}
var LocationSelectValues = []string{"West Europe", "North Europe"}
var MaintenanceSelectValues = []string{"07-09", "09-11", "11-13", "13-15", "15-17", "17-19", "19-21", "21-23", "23-01", "01-03", "03-05", "05-07"}
var ApplicationsSelectValues = []string{"PDF24", "TeamViewer", "Application3"}
var EnvironmentSelectValues = []bool{true, false}
var RecoverySelectValues = []bool{true, false}
var BackupSelectValues = []bool{true, false}
var UserCountSelectValues = []int{100, 200, 500, 1000}

type JsonStruct struct {
	Status    int    `json:"status,omitempty"`
	ErrorText string `json:"errorTextpkg/routesAzTable.goD:/git/go-webserver-admin/pkg/structs.go,omitempty"`
	Meta      struct {
		Key        string `json:"key,omitempty"`
		Name       string `json:"name,omitempty"`
		LastUpdate string `json:"lastUpdate,omitempty"`
	} `json:"meta,omitempty"`
	Configurations []struct {
		Name        string `json:"name,omitempty"`
		LuUpdate    string `json:"luUpdate,omitempty"`
		LuProcessed string `json:"luProcessed,omitempty"`
		Fields      struct {
			Tier struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"tier,omitempty"`
			Location struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"location,omitempty"`
			Usercount struct {
				Values       int `json:"values,omitempty"`
				SelectValues []int `json:"selectValues,omitempty"`
			} `json:"group,omitempty"`
			Maintenance struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"maintenance,omitempty"`
			Environment struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"environment,omitempty"`
			Backup struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"backup,omitempty"`
			Recovery struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"recovery,omitempty"`
			Applications struct {
				Values       []string `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"applications,omitempty"`
		} `json:"fields,omitempty"`
	} `json:"configurations,omitempty"`
}

func (j *JsonStruct) InitStruct() JsonStruct {

	var js JsonStruct
	js.Status = 200
	js.ErrorText = "error"
	js.Meta.Key = "key"
	js.Meta.Name = "name"
	js.Meta.LastUpdate = "lastUpdate"
	js.Configurations = make([]struct {
		Name        string `json:"name,omitempty"`
		LuUpdate    string `json:"luUpdate,omitempty"`
		LuProcessed string `json:"luProcessed,omitempty"`
		Fields      struct {
			Tier struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"tier,omitempty"`
			Location struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"location,omitempty"`
			Usercount struct {
				Values       int `json:"values,omitempty"`
				SelectValues []int `json:"selectValues,omitempty"`
			} `json:"group,omitempty"`
			Maintenance struct {
				Values       string   `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"maintenance,omitempty"`
			Environment struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"environment,omitempty"`
			Backup struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"backup,omitempty"`
			Recovery struct {
				Values       bool   `json:"values,omitempty"`
				SelectValues []bool `json:"selectValues,omitempty"`
			} `json:"recovery,omitempty"`
			Applications struct {
				Values       []string `json:"values,omitempty"`
				SelectValues []string `json:"selectValues,omitempty"`
			} `json:"applications,omitempty"`
		} `json:"fields,omitempty"`
	}, 1)
	js.Configurations[0].Name = ""
	js.Configurations[0].LuUpdate = ""
	js.Configurations[0].LuProcessed = ""
	js.Configurations[0].Fields.Tier.Values = ""
	js.Configurations[0].Fields.Tier.SelectValues = TierSelectValues
	js.Configurations[0].Fields.Location.Values = ""
	js.Configurations[0].Fields.Location.SelectValues = LocationSelectValues
	js.Configurations[0].Fields.Usercount.Values = 100
	js.Configurations[0].Fields.Usercount.SelectValues = UserCountSelectValues
	js.Configurations[0].Fields.Maintenance.Values = ""
	js.Configurations[0].Fields.Maintenance.SelectValues = MaintenanceSelectValues
	js.Configurations[0].Fields.Environment.Values = true
	js.Configurations[0].Fields.Environment.SelectValues = EnvironmentSelectValues
	js.Configurations[0].Fields.Backup.Values = true
	js.Configurations[0].Fields.Backup.SelectValues = BackupSelectValues
	js.Configurations[0].Fields.Recovery.Values = true
	js.Configurations[0].Fields.Recovery.SelectValues = RecoverySelectValues
	js.Configurations[0].Fields.Applications.Values = []string{""}
	js.Configurations[0].Fields.Applications.SelectValues = ApplicationsSelectValues
	return js
}
