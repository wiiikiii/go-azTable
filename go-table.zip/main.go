package main

import (
	m "go-table/pkg"
)

func main() {

	m.Table.ParseCli(m.Table{})

}
